<template>
  <main>
    <h2>GrandPrix et Courses</h2>
    <hr class="dotted">

    <div>
        <div>
        <thead><tr><h2>Résultat de sa carrière</h2></tr></thead>
        </div>
          <tbody>
          <hr class="dotted">
          <tr v-for="championnat in json.resultat" :key="championnat.annee">
            <td>{{championnat.annee}}</td>
            <td>{{championnat.team}}</td>
            <td>{{championnat.gp}}</td>
            <td>{{championnat.position}}</td>
            <router-link :to="{name:'Information',params:{id:resultat.id}}" style="color: #CEA66B;">Informations Supplémentaires</router-link>
          </tr>

          </tbody>
    </div>

    <button>
      <router-link to="/formulaire">Ajouter un résultat</router-link>
    </button>
    <button>
      <router-link to="/edit">Modifier un résultat</router-link>
    </button>
  </main>
</template>

<script>
export default {
  name: "Bibliographie",
  data(){
    return{
      json:[]
    }
  },

  created() {
    axios.get('static/course.json')
      .then(function (response) {
        console.log("Response", response.data);
        this.json = response.data
      }.bind(this))
      .catch(function (error) {
        console.log(error)
      })
  },

}
</script>

<style scoped>
h1 {
  font-size: 40;
  vertical-align: center;
  background-color: #757E7B;
}

h2 {
  font-size: 28;
  text-align: center;
}

h3 {
  font-size: 25;
  text-align: center;
}

thead > tr {
  font-size: 25;
  text-align: center;
}

hr.dotted {
  border-top: 3px dotted #CEA66B;
  border-bottom: none;
  border-right: none;
  border-left: none;
}

button {
  background-color: #CEA66B;
  color: #FFFFFF;
  border-radius: 25px;
  width: 150px;
  height: 50px;
  font-family: Cambria;
  display: block;
  margin : auto;
}

main > div > tbody {
  display: inline;
  width: 1000px;
}

main > div > tbody > tr {
  display: grid;
  justify-content: center;
  grid-template-columns: 1fr 1fr 1fr 1fr;
}

main > div > thead {
  width: 1000px;
  display: inline;
}
</style>
