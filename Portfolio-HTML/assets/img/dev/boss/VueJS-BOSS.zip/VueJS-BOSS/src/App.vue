<template>
  <div id="app">

    <header>
      <h1>
        <nav>
          <img src="@/assets/RG.png"
               width="100px" height="100px" id="logo">
          <router-link to="/">Romain Grosjean</router-link>
          <router-link to="/biographie">Biographie</router-link>
          <router-link to="/lamortenface">La Mort en Face</router-link>
          <router-link to="/bibliographie">GrandPrix et Courses</router-link>
        </nav>
      </h1>
    </header>

    <router-view/>

    <footer>
      <div>
        <span><router-link to="/">Accueil</router-link></span>
        <span><router-link to="/biographie">Biographie</router-link></span>
        <span><router-link to="/lamortenface">La Mort en Face</router-link></span>
        <span><router-link to="/bibliographie">GrandPrix et Courses</router-link></span>
        <span><router-link to="/formulaire">Formulaire</router-link></span>
      </div>
      <div>
        <span><a href="#">Mention Légales</a></span>
        <span><a href="#">Contact</a></span>
      </div>
      <div>
        <div>
          <a href="#"><img src="@/assets/Insta.png" width="50" height="50"></a>
          <a href="#"><img src="@/assets/SM-SOCIAL-MEDIA-ICON-FACEBOOK.png" width="50" height="50"></a>
          <a href="#"><img src="@/assets/twitter.png" width="50" height="50"></a>
        </div>
      </div>
    </footer>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Cambria', sans-serif;
  color: #FFFFFF;
  margin-top: 60px;
  background-color: #26262B;
}

h1 {
  font-size: 40;
  vertical-align: center;
  background-color: #757E7B;
}

h1 > nav > router-link {
  display: inline-flex;
  padding: 50px;
  text-decoration: none;
  color: #FFFFFF;
}

a {
  text-decoration: none;
  color: #FFFFFF;
}

footer {
  display: inline-flex;
  background-color: #757E7B;
  width: 100%;
}

footer > div > span {
  margin-left: 100px;
  margin-bottom: 10px;
  margin-top: 10px;
  display: grid;
  justify-content: center;
  grid-template-columns: 1fr 1fr 1fr;
}

footer > div > span > router-link {
  text-decoration: none;
  color: #FFFFFF;
}
</style>
