<template>
  <main>
    <h2>Biographie</h2>

    <hr class="dotted">

    <div style="
         display: grid;
         justify-content: center;
         grid-template-columns: 1fr 2fr;">
      <div>
        <img src="@/assets/1920px-2017_British_Grand_Prix_(35895518836).png"
             width="600" height="400" style="margin-left: 100px">
      </div>
      <div>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px; margin-top: 50px">Romain Grosjean, né le 17 avril 1986 à Genève, est un pilote automobile helvético-français1. Avec 179 Grands Prix de Formule 1 disputés entre 2009 et 2020, il compte dix podiums, acquis entre 2012 et 2015 pour Lotus F1 Team.</p>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px">
          Après plusieurs années en formules de promotion, en août 2009, à l'occasion du Grand Prix d'Europe à Valence, il fait ses débuts en Formule 1 avec l'équipe Renault F1 Team avant d’être remplacé par Vitaly Petrov en 2010. L'année suivante, il devient champion en GP2 Series avec DAMS. Considéré comme un grand espoir français de la course automobile avec 49 victoires dans diverses formules de promotion, sa première saison complète en Formule 1 en 2012, avec l'équipe Lotus F1 Team, lui permet de monter à trois reprises sur le podium et de mener un Grand Prix malgré un manque de régularité et de multiples incidents de courses, dont un accident pour lequel il écope, de la part des commissaires de course, une suspension d'une course. L'année suivante, il réalise sa meilleure saison dans la discipline en montant à six reprises sur le podium. L'année 2014 se révèle désastreuse à cause d'une voiture beaucoup plus lente. En 2015, l'écurie se redresse et lui permet notamment d'entrer dans les points régulièrement et de monter sur le dixième podium de sa carrière.
        </p>
      </div>
    </div>

    <hr class="dotted">

    <div style="
         display: grid;
         justify-content: center;
         grid-template-columns: 2fr 1fr;">
      <div>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px; margin-top: 50px">Après quatre saisons dans l'équipe britannique, Romain Grosjean rejoint Haas F1 Team en 2016 et marque les premiers points de cette écurie novice américaine dès le Grand Prix d'ouverture à Melbourne, en se classant sixième à l'arrivée. Sa nouvelle équipe lui permet de se battre en milieu de tableau, et d'entrer à plusieurs reprises dans les points. Son contrat n'étant pas renouvelé, il dispute sa dernière année avec Haas en 2020. Sa carrière en Formule 1 s'achève après 179 départs, à la suite d'un effroyable accident au premier tour du Grand Prix de Bahreïn, dont il sort avec des brûlures aux mains qui le contraignent à déclarer forfait pour les deux dernières courses de la saison.</p>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px">En 2021, il participe au championnat Indycar au sein de l'écurie Dale Coyne Racing au volant d'une Dallara-Honda ; il obtient ses premiers pole position et podium dès sa troisième course, au Grand Prix d'Indianapolis.</p>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px">Le 24 septembre 2021, il s'engage avec l'équipe Andretti Autosport pour 2022 où il participera à l'intégralité des courses.</p>
      </div>
      <div>
        <img src="@/assets/1920px-Romain_Grosjean_Haas_VF-18_Barcelona_testing.png"
             width="600" height="400" style="margin-right: 100px">
      </div>
    </div>

    <hr class="dotted">

    <div style="
         display: grid;
         justify-content: center;
         grid-template-columns: 1fr 2fr;">
      <div>
        <img src="@/assets/RomainGrosjean1.png"
             width="600" height="400" style="margin-left: 100px">
      </div>
      <div>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px; margin-top: 50px">
          Il est le fils de Christian Grosjean, avocat suisse à Genève et de Marie-Hélène Brandt, peintre, et l'arrière-petit-fils d'Edgar Brandt, ferronnier d'art et fondateur de Brandt. Il est également le petit-fils du skieur Fernand Grosjean, vice-champion du monde de slalom géant en 1950 à Aspen.
        </p>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px">
          Il épouse la présentatrice et journaliste de télévision Marion Jollès le 27 juin 2012 à Chamonix et est père de deux garçons, Sacha, né le 29 juillet 2013 et Simon, né le 16 mai 2015 et d'une fille, Camille, née le 31 décembre 2017.
        </p>
      </div>
    </div>

    <hr class="dotted">

    <div style="
         display: grid;
         justify-content: center;
         grid-template-columns: 2fr 1fr;">
      <div>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px; margin-top: 50px">Après avoir fait ses classes en karting dans les différents championnats français, Romain Grosjean vient au sport automobile en 2003 par le biais du championnat de Suisse de Formule Renault 1600 qu'il remporte dès sa première saison.
        </p>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px">Romain Grosjean remporte sa première victoire en Formule Renault 2.0 lors de la première course de Dijon-Prenois en résistant aux attaques de Moreau. Lors de la seconde course, sous une pluie torrentielle, Grosjean, qui mène devant Simon Pagenaud et Patrick Pilet, part en tête-à-queue au troisième tour et abandonne. Le Graff Racing, l'écurie rivale de SG Formula, réalise un triplé lors de cette manche.</p>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px">L'année suivante, il remporte le titre en championnat de France Formule Renault 2.0 avec l'écurie SG Formula de Stéphane Guérin et, en 2006, accède au relevé championnat de Formule 3 Euro Series et est treizième du classement général pour sa première saison dans la discipline avec l'écurie Signature. Il rejoint, en 2007, l'écurie ASM Formule 3, victorieuse lors des trois saisons précédentes et remporte le titre à l'issue d'un long duel avec Sébastien Buemi.</p>
      </div>
      <div>
        <img src="@/assets/2012_British_GP_-_Lotus.png"
             width="600" height="400" style="margin-right: 100px">
      </div>
    </div>

    <hr class="dotted">

    <div>
      <p style="text-align: center; margin-left: 200px; margin-right: 200px; margin-top: 50px">
        En 2008, il dispute le championnat de GP2 Series au sein de l'écurie ART Grand Prix (émanation de ASM F3) de Fred Vasseur et Nicolas Todt. Pour parfaire sa connaissance de la discipline et de sa nouvelle équipe, Grosjean participe durant l'hiver 2008 au nouveau championnat GP2 Asia Series dont il remporte à Dubai les deux premières manches (fait unique pour un débutant dans cette catégorie) après s'être élancé de la pole position dans la première course puis de la huitième place, selon le principe de la grille inversée, dans la deuxième course. Il remporte le titre de champion du GP2 Asia deux courses avant la fin avec un total de quatre victoires et cinq pole positions sur six possibles.
      </p>
      <p style="text-align: center; margin-left: 200px; margin-right: 200px">
        En 2009, Romain Grosjean est promu troisième pilote du Renault F1 Team et participe parallèlement au championnat GP2 Series avec le Team Barwa Addax (ex-Campos Racing). Pour sa deuxième saison en GP2, il réalise un hat-trick lors de la course longue de Barcelone et gagne à Monaco pour s'installer en tête du championnat. Lors des courses suivantes, il est impliqué dans quelques accidents et malgré de nouvelles pole positions et plusieurs places d'honneur, il cède la tête du championnat à Nico Hülkenberg
      </p>
      <p style="text-align: center; margin-left: 200px; margin-right: 200px">
        Sa saison en GP2 s'arrête pourtant lorsque, en août 2009, l'écurie Renault F1 Team annonce qu'il remplace dorénavant Nelson Angelo Piquet en Formule 1. Il devient le coéquipier de Fernando Alonso, mais sa demi-saison est difficile : il rejoint une écurie en pleine crise après l'affaire du Singaporegate et sans avoir effectué la moindre séance d'essai avant de débuter, il ne marque aucun point et se retrouve sans volant en Formule 1 à l'issue de la saison.
      </p>
      <img src="@/assets/R_Grosjean_Monza_2011_GP2.png" width="900" height="600" style="margin-left: 400px">
    </div>

    <hr class="dotted">

    <div>
      <p style="text-align: center; margin-left: 200px; margin-right: 200px; margin-top: 50px">
        Le 9 décembre 2011, Romain Grosjean est nommé pilote titulaire au sein de l'équipe Lotus F1 Team pour la saison 2012 et devient le coéquipier de l'ancien champion du monde Kimi Räikkönen.    </p>
      <p style="text-align: center; margin-left: 200px; margin-right: 200px">
        Le 29 septembre 2015, lors d'une conférence de presse à l'usine de Kannapolis, la nouvelle équipe de Formule 1, Haas F1 Team annonce le recrutement du pilote Romain Grosjean pour une saison.    </p>
      <p style="text-align: center; margin-left: 200px; margin-right: 200px">
        La pandémie de Covid-19 perturbe fortement le championnat 2020, comme l'ensemble des manifestations sportives dans le monde ; si bien que la saison débute en Autriche le 5 juillet. Lors de la première épreuve de la saison, Romain Grosjean rencontre de nombreux soucis de freins qui l'obligent à abandonner en course. En Espagne, il connaît un weekend compliqué et se classe dernier à la suite d'un demi tête-à-queue en fin d'épreuve. Qualifié en seizième position du Grand Prix de l'Eifel, il inscrit ses uniques points de la saison grâce à une neuvième place. Le 22 octobre 2020, en marge du Grand Prix du Portugal, il annonce que Haas ne renouvellera pas son contrat et que 2020 est sa dernière saison au sein de l'équipe.
        À Bahreïn, il percute Daniil Kvyat dans le premier tour et tape le rail de face à pleine vitesse dans un choc mesuré à 53 g ; sa monoplace, brisée en deux et dont la cellule de survie est complètement encastrée dans les barrières s'embrase immédiatement ; le Français, qui réussit à s'extraire seul du brasier, est ensuite héliporté vers un hôpital pour subir des examens ; il ne présente que des brûlures aux mains et aux pieds. Forfait pour le Grand Prix de Sakhir, il doit attendre l'autorisation des médecins pour disputer, à Abou Dabi, le dernier Grand Prix de sa carrière. Malgré son optimisme exprimé lors de la visite du paddock au Grand Prix de Sakhir, il déclare forfait pour la manche finale du championnat, ce qui met fin à sa carrière en Formule 1. Grosjean se classe ainsi dix-neuvième du championnat avec 2 points.    </p>
      </br>
      <button>
        <a href="la-mort-en-face.html">En savoir plus</a>
      </button>
      </br>
      <img src="@/assets/R_Grosjean_2020_Accident.jpg" width="900" height="600" style="margin-left: 400px">
    </div>

    <hr class="dotted">

    <div>
      <p style="text-align: center; margin-left: 200px; margin-right: 200px; margin-top: 50px">En 2021, il participe au championnat IndyCar Series au sein de l'écurie Dale Coyne Racing au volant d'une Dallara-Honda.
        Le 5 mai, en guise de cadeau d'adieu à la Formule 1, il est invité par Mercedes à prendre le volant de la Mercedes-AMG F1 W10 EQ Power+ lors du week-end du Grand Prix de France au Castellet, mi-juin. Ce test est finalement reporté en raison d'un problème de dates entre le pilote français et l'écurie allemande.
        Romain Grosjean obtient sa première pole position et son premier podium dès sa troisième course, le Grand Prix automobile d'Indianapolis sur le circuit routier d'Indianapolis, où il se classe deuxième. Il termine à nouveau deuxième lors du second Grand Prix d'Indianapolis de la saison puis troisième à Laguna Seca. Finalement, pour sa première saison dans la discipline, il termine 15e au championnat et échoue à quelques points du titre de Rookie de l'année face à Scott McLaughlin et ce malgré sa non participation aux deux Grand Prix du Texas et aux 500 miles d'Indianapolis.
        Il rejoint ensuite Andretti Autosport pour la saison 2022 en remplacement de Ryan Hunter-Reay.</p>
    </div>
  </main>
</template>

<script>
export default {
  name: "Biographie"
}
</script>

<style scoped>
h1 {
  font-size: 40;
  vertical-align: center;
  background-color: #757E7B;
}

h2 {
  font-size: 28;
  text-align: center;
}

h3 {
  font-size: 25;
  text-align: center;
}

hr.dotted {
  border-top: 3px dotted #CEA66B;
  border-bottom: none;
  border-right: none;
  border-left: none;
}

button {
  background-color: #CEA66B;
  color: #FFFFFF;
  border-radius: 25px;
  width: 150px;
  height: 50px;
  font-family: Cambria;
  display: block;
  margin : auto;
}

img {
  border-radius: 25px;
}
</style>
