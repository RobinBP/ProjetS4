import Vue from 'vue'
import Router from 'vue-router'
import Accueil from "@/components/Accueil";
import Biographie from "@/components/Biographie";
import Bibliographie from "@/components/Bibliographie";
import Formulaire from "@/components/Formulaire";
import LaMortEnFace from "@/components/LaMortEnFace";
import Edit from "@/components/Edit";
import Information from "@/components/Information";

Vue.use(Router)

export default new Router({
  routes: [
    { path: '/',                name: 'Accueil',                    component: Accueil } ,
    { path: '/biographie',      name: 'Biographie',                 component: Biographie } ,
    { path: '/bibliographie',   name: 'GrandPrix et Courses',       component: Bibliographie } ,
    { path: '/formulaire',      name: 'Formulaire',                 component: Formulaire } ,
    { path: '/lamortenface',    name: 'La Mort en Face',            component: LaMortEnFace } ,
    { path: '/information/:id', name: 'Information',                component: Information } ,
    { path: '/edit',            name: 'Edit',                       component: Edit }
  ]
})
