<template>
  <main>
    <h2>Édition</h2>

    <hr class="dotted">

    <form>
      <label for="annee">Année</label></br>
      <input type="text" id="annee" name="Année"></br>

      <label for="team">Team</label></br>
      <input type="text" id="team" name="Team"></br>

      <label for="gp">Nombre de GrandPrix</label></br>
      <input type="text" id="gp" name="GrandPrix"></br>

      <label for="position">Positionnement</label></br>
      <input type="text" id="position" name="Positionnement"></br>

      <input type="submit" value="Envoyer">
    </form>
  </main>
</template>

<script>
export default {
  name: "Edit"
}
</script>

<style scoped>
h1 {
  font-size: 40;
  vertical-align: center;
  background-color: #757E7B;
}

h2 {
  font-size: 28;
  text-align: center;
}

h3 {
  font-size: 25;
  text-align: center;
}

hr.dotted {
  border-top: 3px dotted #CEA66B;
  border-bottom: none;
  border-right: none;
  border-left: none;
}

button {
  background-color: #CEA66B;
  color: #FFFFFF;
  border-radius: 25px;
  width: 150px;
  height: 50px;
  font-family: Cambria;
  display: block;
  margin : auto;
}

input[type=text] {
  border: 2px solid #CEA66B;
  border-radius: 25px;
  background-color: #26262B;
  width: 500px;
  height: 50px;
  padding-bottom: 10px;

}

input[type=submit] {
  background-color: #CEA66B;
  border-radius: 25px;
  width: 150px;
  height: 50px;
  border: none;
}
img {
  border-radius: 25px;
}
</style>
