<template>
  <main>
    <h2>Accueil</h2>

    <hr class="dotted">

    <div style="
         display: grid;
         justify-content: center;
         grid-template-columns: 2fr 1fr;">
      <div>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px; margin-top: 150px">
          Romain Grosjean, âgé de 35 ans et né le 17 avril 1986 est un
          pilote automobile. Anciennement coureur dans la Formule 1 (F1)
          après avoir été coureur dans la GP2 et le karting, il est aujourd’hui
          coureur dans l’IndyCar Series à la suite d’un grave accident de F1 en 2020
          lors du championnat saisonnier au GP (Grand-Prix) de Bahreïn …
        </p>
        </br>
        <button>
          <router-link to="/biographie">En savoir plus</router-link>
        </button>
      </div>
      <div>
        <img src="@/assets/RomainGrosjean2.png"
             width="600" height="400" style=" margin-right: 100px">
      </div>
    </div>

    <hr class="dotted">

    <div style="
         display: grid;
         justify-content: center;
         grid-template-columns: 1fr 2fr;">
      <div>
        <img src="@/assets/R_Grosjean_Monza_2011_GP2.png"
             width="600" height="400"  style="margin-left: 100px">
      </div>
      <div>
        <p style="text-align: right; margin-right: 200px; margin-left: 200px; margin-top: 150px">
          Découvrez l'histoire de Romain Grosjean en  survolant ses résultats
          en Formule de promotion (GP2, …), en Formule 1 et plus récemment
          en IndyCar Series. Vous retrouverez positionnement, équipes
          ou bien encore le chassis utilisé.
        </p>
        </br>
        <button>
          <router-link to="/bibliographie">En savoir plus</router-link>
        </button>
      </div>
    </div>
  </main>
</template>

<script>
export default {
  name: "Accueil"
}
</script>

<style scoped>
h1 {
  font-size: 40;
  vertical-align: center;
  background-color: #757E7B;
}

h2 {
  font-size: 28;
  text-align: center;
}

h3 {
  font-size: 25;
  text-align: center;
}

hr.dotted {
  border-top: 3px dotted #CEA66B;
  border-bottom: none;
  border-right: none;
  border-left: none;
}

button {
  background-color: #CEA66B;
  color: #FFFFFF;
  border-radius: 25px;
  width: 150px;
  height: 50px;
  font-family: Cambria;
  display: block;
  margin : auto;
}

img {
  border-radius: 25px;
}
</style>
