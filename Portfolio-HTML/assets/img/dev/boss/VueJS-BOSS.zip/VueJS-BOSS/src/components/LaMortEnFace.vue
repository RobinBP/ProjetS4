<template>
  <main>
    <h2>La Mort en Face</h2>

    <hr class="dotted">

    <div style="
         display: grid;
         justify-content: center;
         grid-template-columns: 1fr 2fr;">
      <div>
        <video  preload="auto" autoplay style="width: 750px; height: 500px; margin-top: 100px; margin-left: 25px">
          <source src="@/assets/video.mp4" type="video/mp4">
        </video>
      </div>
      <div>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px; margin-top: 50px">
          Romain Grosjean ne l'oubliera jamais. Le 29 novembre 2020, le pilote de Formule 1 et mari de Marion Jollès-Grosjean a été victime d'un grave accident. Il a frôlé la mort durant le Grand Prix de Bahreïn en faisant une sortie de piste à 220 km/h, avant que son bolide ne soit coupé en deux et prenne feu en percutant un rail de sécurité. Resté bloqué quelques secondes dans son véhicule, Romain Grosjean a donc vu sa vie défiler, avant de pouvoir ressortir vivant mais avec de grosses séquelles. Outre le traumatisme psychologique, l'époux de la journaliste de TF1 a souffert de très graves brûlures aux chevilles et aux mains. Près d'un an plus tard, la star des Grands Prix a repris du service mais garde toujours ses cicatrices sur les mains qui lui rappellent qu'il a échappé de peu au pire.
        </p>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px">
          Impossible donc pour Romain Grosjean de tourner la page sur ce drame qui a totalement changé sa vision de la vie. Il a même sorti avec sa femme le livre La Mort en face pour évoquer ce jour où tout a basculé. "L'un des points positifs, c'est que l'on relativise beaucoup plus les petits soucis du quotidien. On profite deux fois plus de la vie", a-t-il confié à Télé 7 Jours. Des propos confirmés par Marion Jollès-Grosjean pour qui il y a "un avant et un après". "Je croyais avoir vécu le plus difficile dans l'attente de voir si Romain allait ou non s'extirper de sa voiture. Or, l'après a été plus compliqué à gérer. Je pensais à ce qu'il serait advenu de moi et de nos enfants si Romain n'était pas sorti vivant de la voiture. Cela me hante encore aujourd'hui", a-t-elle expliqué.
        </p>
        <p style="text-align: center; margin-left: 200px; margin-right: 200px">
          Romain Grosjean est d'autant plus troublé par cet accident qu'il aurait pu finir décapité ! Le pilote de Formule 1 doit surtout sa vie au halo, un arceau de protection autour de la tête. Un accessoire qu'il avait pourtant vivement critiqué au moment de son instauration. "J'avoue que, sans lui, j'aurais eu la tête coupée, a-t-il révélé. Mais si le halo a été rendu obligatoire après l'accident de Jules Bianchi, en 2014, il n'aurait pas pu lui sauver la vie. Le halo ne peut pas tout empêcher, cela dépend de la nature de l'impact". Il lui doit cependant la vie.
        </p>
      </div>
    </div>

    <hr class="dotted">
  </main>
</template>

<script>
export default {
  name: "La Mort en Face"
}
</script>

<style scoped>
h1 {
  font-size: 40;
  vertical-align: center;
  background-color: #757E7B;
}

h2 {
  font-size: 28;
  text-align: center;
}

h3 {
  font-size: 25;
  text-align: center;
}

hr.dotted {
  border-top: 3px dotted #CEA66B;
  border-bottom: none;
  border-right: none;
  border-left: none;
}

button {
  background-color: #CEA66B;
  color: #FFFFFF;
  border-radius: 25px;
  width: 150px;
  height: 50px;
  font-family: Cambria;
  display: block;
  margin : auto;
}
</style>
