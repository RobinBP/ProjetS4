<template>
  <main>
    <h2>Information</h2>

    <hr class="dotted">

      <p>{{json.id}}</p>
      <p>{{json.annee}}</p>
      <p>{{json.team}}</p>
      <p>{{json.gp}}</p>
      <p>{{json.victoire}}</p>
      <p>{{json.position}}</p>

  </main>
</template>

<script>
export default {
  name: "Information",
  data(){
    return{
      json:[],
      id: 0
    }
  },

  created() {
    this.id = this.$route.params.id;
    axios.get('static/course.json')
      .then(function (response) {
        console.log("Response", response.data);
        this.json = response.data.resultat[(this.id)];
        console.log("Response", this.json);
      }.bind(this))
      .catch(function (error) {
        console.log(error)
      })
  },

}
</script>

<style scoped>
h1 {
  font-size: 40;
  vertical-align: center;
  background-color: #757E7B;
}

h2 {
  font-size: 28;
  text-align: center;
}

h3 {
  font-size: 25;
  text-align: center;
}

hr.dotted {
  border-top: 3px dotted #CEA66B;
  border-bottom: none;
  border-right: none;
  border-left: none;
}

button {
  background-color: #CEA66B;
  color: #FFFFFF;
  border-radius: 25px;
  width: 150px;
  height: 50px;
  font-family: Cambria;
  display: block;
  margin : auto;
}

#css {
  border: 2px solid #CEA66B;
  border-radius: 25px;
  background-color: #26262B;
  width: 500px;
  height: 50px;
  padding-bottom: 10px;
  color: #FFFFFF;
}

input::placeholder {
  color: #FFFFFF;
}

input[type=submit] {
  background-color: #CEA66B;
  border-radius: 25px;
  width: 150px;
  height: 50px;
  border: none;
}
img {
  border-radius: 25px;
}
</style>
